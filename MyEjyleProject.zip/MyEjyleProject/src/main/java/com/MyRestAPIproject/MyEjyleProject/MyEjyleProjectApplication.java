package com.MyRestAPIproject.MyEjyleProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyEjyleProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyEjyleProjectApplication.class, args);
	}

}
