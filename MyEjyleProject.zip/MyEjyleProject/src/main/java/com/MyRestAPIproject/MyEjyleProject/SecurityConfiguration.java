package com.MyRestAPIproject.MyEjyleProject;

import javax.activation.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter
{
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	private javax.sql.DataSource dataSource;
	
	@Value("${spring.queries.emps-query}")    // Query for authentication
	private String empsQuery;
	

	@Value("${spring.queries.roles-query}")     // Query for authorization
	private String rolesQuery;
	
	@Override
	protected void configure(AuthenticationManagerBuilder ejyle) throws Exception
	{
		ejyle.jdbcAuthentication().usersByUsernameQuery(empsQuery).authoritiesByUsernameQuery(rolesQuery)
		.dataSource(dataSource).passwordEncoder(bCryptPasswordEncoder);
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception
	{
		http.authorizeHttpRequests()
		//URLs matching for access rights
		.antMatchers("/").permitAll()
		.antMatchers("/login").permitAll()
		.antMatchers("/register").permitAll()
		.antMatchers("/home/**").hasAnyAuthority("SUPER_EMP", "ADMIN_EMP", "SITE_EMP")
		.and()
		.csrf().disable().formLogin()
		.loginPage("/login")
		.failureForwardUrl("/login?error=true")
		.defaultSuccessUrl("/home")
		.usernameParameter("email")
		.passwordParameter("password")
		.and()
		// logout
		.logout()
		.logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
		.logoutSuccessUrl("/").and()
		.exceptionHandling()
		.accessDeniedPage("/access-denied");
	}

		@Override
		public void configure(WebSecurity web) throws Exception {
			web.ignoring().antMatchers("/resources/**", "/static/**", "/css/**", "/js/**", "/images/**");
		}

}
